csv-visualiser
==============

London Clojure Dojo Late August 2014:
basic Om application that allows you
to drag and drop csv file and show its contents 
in a table.
